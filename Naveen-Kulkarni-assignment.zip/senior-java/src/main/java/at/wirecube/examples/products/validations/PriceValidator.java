package at.wirecube.examples.products.validations;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
public class PriceValidator implements ConstraintValidator<PriceValidation, Double> {

	@Override
	public boolean isValid(Double value, ConstraintValidatorContext context) {
		if(null!=value && value.toString().matches("[0-9]{1,13}(\\.[0-9]*)?")) {
			return true;
		}
		return false;
	}

}
