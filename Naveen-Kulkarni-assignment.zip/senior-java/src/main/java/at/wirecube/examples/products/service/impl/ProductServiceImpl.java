package at.wirecube.examples.products.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import at.wirecube.examples.products.domain.Product;
import at.wirecube.examples.products.dto.ProductDTO;
import at.wirecube.examples.products.exception.ProductNotFoundException;
import at.wirecube.examples.products.mapper.ProductMapper;
import at.wirecube.examples.products.repository.ProductRepository;
import at.wirecube.examples.products.service.ProductService;
import lombok.extern.slf4j.Slf4j;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
@Service
@Slf4j
public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository;

	private ProductMapper productMapper;

	@Autowired
	public ProductServiceImpl(ProductRepository productRepository, ProductMapper productMapper) {
		this.productRepository = productRepository;
		this.productMapper = productMapper;
	}

	@Override
	public ProductDTO getProductById(Long productId) {
		log.info("Entered: ProductServiceImpl: getProductById: With ID: " + productId);
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ProductNotFoundException("Product Not found: " + productId));
		return productMapper.toDTO(product);
	}

	@Override
	public List<ProductDTO> getProducts() {
		log.info("Entered: ProductServiceImpl: getProducts");
		List<Product> products = productRepository.findAll();
		List<ProductDTO> productDTOs = new ArrayList<>();
		for (Product product : products) {
			ProductDTO productDTO = productMapper.toDTO(product);
			productDTOs.add(productDTO);
		}
		return productDTOs;
	}

	@Override
	public ProductDTO saveProduct(ProductDTO productDTO) {
		log.info("Entered: ProductServiceImpl: saveProduct: With :" + productDTO);
		Product product = productMapper.toDomain(productDTO);
		product = productRepository.save(product);
		return productMapper.toDTO(product);
	}

	@Override
	public ProductDTO updateProduct(Long productId, ProductDTO productDTO) {
		log.info("Entered: ProductServiceImpl: updateProduct: ProductId: " + productId + ", Product: " + productDTO);
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ProductNotFoundException("Product Not found: " + productId));
		product = productMapper.toDomain(productDTO);
		product.setProductId(productId);
		product = productRepository.save(product);
		return productMapper.toDTO(product);
	}

	@Override
	public void deleteProduct(Long productId) {
		log.info("Entered: ProductServiceImpl: deleteProduct: With: " + productId);
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ProductNotFoundException("Product Not found: " + productId));
		productRepository.delete(product);
	}

}
