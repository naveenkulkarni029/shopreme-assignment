package at.wirecube.examples.products.dto;

import org.springframework.hateoas.RepresentationModel;

import com.fasterxml.jackson.annotation.JsonProperty;

import at.wirecube.examples.products.validations.NameValidation;
import at.wirecube.examples.products.validations.PriceValidation;
import at.wirecube.examples.products.validations.VatValidation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.AccessMode;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
public class ProductDTO extends RepresentationModel<ProductDTO> {

	@Schema(accessMode = AccessMode.READ_ONLY, name = "pid")
	@JsonProperty("pid")
	private long productId;

	@Schema(name = "pName", example = "Naveen")
	@JsonProperty("pName")
	@NameValidation()
	private String productName;

	@Schema(name = "pPrice", example = "100")
	@JsonProperty("pPrice")
	@PriceValidation()
	private Double productPrice;

	@Schema(name = "pDesc", example = "Product Description")
	@JsonProperty("pDesc")
	private String productDesc;

	@Schema(name = "pVat", example = "10")
	@JsonProperty("pVat")
	@VatValidation()
	private int productVat;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public int getProductVat() {
		return productVat;
	}

	public void setProductVat(int productVat) {
		this.productVat = productVat;
	}

	@Override
	public String toString() {
		return "ProductDTO [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productDesc=" + productDesc + ", productVat=" + productVat + "]";
	}

}
