package at.wirecube.examples.products.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import at.wirecube.examples.products.enums.VAT;
import lombok.Data;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
@Entity(name = "products")
@Data
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long productId;

	@Column(name = "name")
	private String productName;

	@Column(name = "price")
	private Double productPrice;

	@Column(name = "description")
	private String productDesc;

	@Column(name = "vat")
	@Enumerated(value = EnumType.ORDINAL)
	private VAT productVat;

}
