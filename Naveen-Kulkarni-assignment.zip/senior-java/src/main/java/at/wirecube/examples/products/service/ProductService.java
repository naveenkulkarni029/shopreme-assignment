package at.wirecube.examples.products.service;

import java.util.List;

import at.wirecube.examples.products.dto.ProductDTO;

/**
 * 
 * @author Naveen Kulkarni
 *
 */
public interface ProductService {

	/**
	 * This method is used to get the detail of the product from the database.
	 * 
	 * @param productId
	 * @return {@link ProductDTO}
	 */

	public ProductDTO getProductById(Long productId);

	/**
	 * This method is used to get all the products from the database.
	 * 
	 * @return
	 */

	public List<ProductDTO> getProducts();

	/**
	 * This method is used to create an product or save to the database.
	 * 
	 * @param productDTO
	 * @return {@link ProductDTO}
	 */
	public ProductDTO saveProduct(ProductDTO productDTO);

	/**
	 * This method is used to update the product.
	 * 
	 * @param productId
	 * @return {@link ProductDTO}
	 */

	public ProductDTO updateProduct(Long productId, ProductDTO productDTO);

	/**
	 * This method is used to delete the product.
	 * 
	 * @param productId
	 */

	public void deleteProduct(Long productId);

}
