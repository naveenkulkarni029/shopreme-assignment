package at.wirecube.examples.products.enums;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
public enum VAT {
	VAT_10(10), VAT_18(18), VAT_20(20);

	private final int value;

	VAT(final int newValue) {
		value = newValue;
	}

	public int getValue() {
		return value;
	}
}
