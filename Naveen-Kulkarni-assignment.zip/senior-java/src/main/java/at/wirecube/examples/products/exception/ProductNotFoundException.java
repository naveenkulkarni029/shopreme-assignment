package at.wirecube.examples.products.exception;
/**
 * 
 * @author Naveen Kulkarni
 *
 */
public class ProductNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4256242741316292524L;

	public ProductNotFoundException(String message) {
		super(message);
	}

}
