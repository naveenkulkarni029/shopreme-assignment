package at.wirecube.examples.products.validations;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * @author Naveen Kulkarni
 *
 */
public class NameValidator implements ConstraintValidator<NameValidation, String> {

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return !StringUtils.isBlank(value);
	}

}
