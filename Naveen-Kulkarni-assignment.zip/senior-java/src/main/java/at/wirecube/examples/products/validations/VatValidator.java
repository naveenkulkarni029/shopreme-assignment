package at.wirecube.examples.products.validations;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import at.wirecube.examples.products.enums.VAT;

/**
 * 
 * @author Naveen Kulkarni
 *
 */
public class VatValidator implements ConstraintValidator<VatValidation, Integer> {

	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		for (VAT e : VAT.values()) {
			if (e.getValue() == value) {
				return true;
			}
		}
		return false;
	}

}
