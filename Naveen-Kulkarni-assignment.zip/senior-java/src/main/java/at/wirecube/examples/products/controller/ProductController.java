package at.wirecube.examples.products.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import at.wirecube.examples.products.dto.ProductDTO;
import at.wirecube.examples.products.service.ProductService;

/**
 * Product Controller is an entry point for the application. This Controller
 * supports four end points.
 * 
 * <p>
 * 1. Create an Product: The endpoint is a HTTP Post request which accepts the
 * ProductDTO as a request body. Returns {@code HttpStatus} 201 Created on
 * successfully saving the Product into the database. Along with the Response
 * code 201. The endpoint also returns the stored product details along with the
 * HATEOAS for further process.
 * 
 * <p>
 * 2. Get Product by Id: The endpoint is a HTTP Get Request which accepts the
 * productId as the Path variable. Returns a {@code HttpStatus} 200 OK on
 * successfully fetch of product from the database. Returns {@code HttpStatus}
 * 404 NOT FOUND if the requested product Id is not found in the database.
 * 
 * <p>
 * 3. Get All Products: The endpoint is a HTTP Get Request which Returns a
 * {@code HttpStatus} 200 OK irrespective of data being available or not in the
 * database.
 * 
 * <p>
 * 4. Update the Product: The endpoint is a HTTP PUT Request accepts the product
 * Id as a Path Variable and the ProductDTO information as a request body. On
 * successfully updating the Product the endpoint returns a {@code HttpStatus}
 * 200 OK along with the Product details along with the HATEOAS. On failure
 * returns an ProductNotFound Exception error message along with the HTTP Status
 * Code 404.
 * 
 * <p>
 * 5. Delete the Product: The endpoint is a HTTP DELETE Request accepts the
 * product Id as a Path Variable. On successfully deletion of the Product the
 * endpoint returns a {@code HttpStatus} 204 NO CONTENT. On failure returns an
 * ProductNotFoundException error message along with the HTTP Status Code 404.
 *
 * @author Naveen Kulkarni
 */

@RestController
@RequestMapping(value = "/api/v1/products")
public class ProductController {

	private ProductService productService;

	@Autowired
	public ProductController(ProductService productService) {
		this.productService = productService;
	}

	/**
	 * Get Product by Id: The endpoint is a HTTP Get Request which accepts the
	 * productId as the Path variable. Returns a {@code HttpStatus} 200 OK on
	 * successfully fetch of product from the database. Returns {@code HttpStatus}
	 * 404 NOT FOUND if the requested product Id is not found in the database.
	 * 
	 * @param productId
	 * @return {@code ProductDTO}
	 */

	@ResponseStatus(code = HttpStatus.OK)
	@GetMapping(value = "/{productId}")
	public ProductDTO getProductById(@PathVariable Long productId) {
		ProductDTO product = productService.getProductById(productId);
		Link selfLink = linkTo(ProductController.class).slash(product.getProductId()).withSelfRel();
		product.add(selfLink);
		return product;
	}

	/**
	 * The endpoint is a HTTP Get Request which Returns a {@code HttpStatus} 200 OK
	 * irrespective of data being available or not in the database.
	 * 
	 * @return {@code List} of {@code ProductDTO}
	 */

	@ResponseStatus(code = HttpStatus.OK)
	@GetMapping
	public List<ProductDTO> getProducts() {
		List<ProductDTO> products = productService.getProducts();
		for (ProductDTO product : products) {
			Link selfLink = linkTo(ProductController.class).slash(product.getProductId()).withSelfRel();
			product.add(selfLink);
		}
		return products;
	}

	/**
	 * Create an Product: The endpoint is a HTTP Post request which accepts the
	 * PProductDTO as a request body. Returns {@code HttpStatus} 201 Created on
	 * successfully saving the Product into the database. Along with the Response
	 * code 201. The endpoint also returns the stored product details along with the
	 * HATEOAS for further process.
	 * 
	 * @param productDTO
	 * @return {@code ProductDTO}
	 */

	@ResponseStatus(code = HttpStatus.CREATED)
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ProductDTO saveProduct(@Valid @RequestBody ProductDTO productDTO) {
		ProductDTO product = productService.saveProduct(productDTO);
		Link selfLink = linkTo(ProductController.class).slash(product.getProductId()).withSelfRel();
		product.add(selfLink);
		return product;
	}

	/**
	 * Update the Product: The endpoint is a HTTP PUT Request accepts the product Id
	 * as a Path Variable and the ProductDTO as a request body. On successfully
	 * updating the product the endpoint returns a {@code HttpStatus} 200 OK along
	 * with the product details and HATEOAS.
	 * 
	 * @param productId
	 * @param productDTO
	 * @return {@code ProductDTO}
	 */

	@ResponseStatus(code = HttpStatus.OK)
	@PutMapping(value = "/{productId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ProductDTO updateProductById(@PathVariable Long productId, @Valid @RequestBody ProductDTO productDTO) {
		ProductDTO product = productService.updateProduct(productId, productDTO);
		Link selfLink = linkTo(ProductController.class).slash(product.getProductId()).withSelfRel();
		product.add(selfLink);
		return product;
	}

	/**
	 * Delete the Product: The endpoint is a HTTP DELETE Request accepts the product
	 * Id as a Path Variable. On successfully deletion of the Product the endpoint
	 * returns a {@code HttpStatus} 204 NO CONTENT. On failure returns an
	 * ProductNotFoundException error message along with the HTTP Status Code 404.
	 * 
	 * @param productId
	 */

	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping(value = "/{productId}")
	public void deleteProductById(@PathVariable Long productId) {
		productService.deleteProduct(productId);
	}

}
