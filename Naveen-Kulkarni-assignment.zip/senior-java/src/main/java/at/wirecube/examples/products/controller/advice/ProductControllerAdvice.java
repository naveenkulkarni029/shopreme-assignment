package at.wirecube.examples.products.controller.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import at.wirecube.examples.products.exception.ProductNotFoundException;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Naveen Kulkarni
 *
 */

@RestControllerAdvice
@Slf4j
public class ProductControllerAdvice {

	/**
	 * This method is an exception flow for get product by id, update, and delete of
	 * the product.
	 * 
	 * @param exception
	 * @return payload
	 */

	@ResponseStatus(code = HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = { ProductNotFoundException.class })
	public Object handleProductNotFoundExceptionEmployeeNotFoundException(ProductNotFoundException exception) {
		log.info(exception.getLocalizedMessage(), exception);
		return createMessage(exception.getLocalizedMessage(), HttpStatus.NOT_FOUND);
	}

	/**
	 * 
	 * @param exceptionMessage
	 * @param httpStatus
	 * @return {@code Map} of payload
	 */
	private Map<String, Object> createMessage(String exceptionMessage, HttpStatus httpStatus) {
		Map<String, Object> map = new HashMap<>();
		map.put("message", exceptionMessage);
		map.put("status", httpStatus.value());
		map.put("error", httpStatus.getReasonPhrase());
		map.put("timestamp", System.currentTimeMillis());
		return map;
	}

}
