package at.wirecube.examples.products.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import at.wirecube.examples.products.domain.Product;
import at.wirecube.examples.products.dto.ProductDTO;
import at.wirecube.examples.products.enums.VAT;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Naveen Kulkarni
 *
 */
@Component
@Slf4j
public class ProductMapper {

	/**
	 * As the method name says it is used to convert the Entity / Domain Object to
	 * DTO Object. The method uses the {@link BeanUtils} Class to copy the
	 * {@link Product} to {@link ProductDTO}
	 * 
	 * @param product
	 * @return {@link ProductDTO}
	 */

	public ProductDTO toDTO(Product product) {
		log.info("Entered: ProductMapper: toDTO");
		ProductDTO productDTO = new ProductDTO();
		BeanUtils.copyProperties(product, productDTO, "productVat");
		productDTO.setProductVat(product.getProductVat().getValue());
		log.info("Exit: ProductMapper: toDTO");
		return productDTO;
	}

	/**
	 * As the method name says it is used to convert the DTO object to the entity /
	 * domain object before saving to the database.
	 * 
	 * The method uses {@link BeanUtils} class to copy the information from the
	 * {@link ProductDTO} to {@link Product}
	 * 
	 * 
	 * @param productDTO
	 * @return {@link Product}
	 */

	public Product toDomain(ProductDTO productDTO) {
		log.info("Entered: ProductMapper: toDomain: " + productDTO);
		Product product = new Product();
		BeanUtils.copyProperties(productDTO, product);
		product.setProductVat(getVAT(productDTO.getProductVat()));
		log.info("Exit: ProductMapper: toDomain: " + product);
		return product;
	}

	public VAT getVAT(int value) {
		VAT vat = null;
		for (VAT e : VAT.values()) {
			if (e.getValue() == value) {
				vat = e;
				break;
			}
		}
		return vat;
	}

}
