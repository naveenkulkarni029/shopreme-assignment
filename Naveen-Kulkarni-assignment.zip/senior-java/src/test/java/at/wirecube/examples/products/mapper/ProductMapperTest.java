package at.wirecube.examples.products.mapper;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import at.wirecube.examples.products.domain.Product;
import at.wirecube.examples.products.dto.ProductDTO;

@ExtendWith(MockitoExtension.class)
public class ProductMapperTest {

	@InjectMocks
	private ProductMapper productMapper;

	private ObjectMapper objectMapper;

	private ProductDTO productDTORequest;

	private ProductDTO productDTOResponse;

	private Product productEntityRequest;

	private Product productEntityResponse;

	@BeforeEach
	public void setup() throws JsonParseException, JsonMappingException, IOException {
		MockitoAnnotations.openMocks(this);
		objectMapper = new ObjectMapper();

		File productDTORequestFile = new File("src/test/resources/product-dto-request.json");
		Assertions.assertTrue(productDTORequestFile.exists());
		productDTORequest = objectMapper.readValue(productDTORequestFile, ProductDTO.class);

		File productDTOResponseFile = new File("src/test/resources/product-dto-response.json");
		Assertions.assertTrue(productDTOResponseFile.exists());
		productDTOResponse = objectMapper.readValue(productDTOResponseFile, ProductDTO.class);

		File productEntityRequestFile = new File("src/test/resources/product-entity-request.json");
		Assertions.assertTrue(productEntityRequestFile.exists());
		productEntityRequest = objectMapper.readValue(productEntityRequestFile, Product.class);

		File productEntityResponseFile = new File("src/test/resources/product-entity-response.json");
		Assertions.assertTrue(productEntityResponseFile.exists());
		productEntityResponse = objectMapper.readValue(productEntityResponseFile, Product.class);

	}

	@Test
	public void toDTOTestSuccess() {
		ProductDTO actualProductDTO = productMapper.toDTO(productEntityResponse);
		Assertions.assertEquals(productDTOResponse, actualProductDTO);
	}

	@Test
	public void toDomainTestSuccess() {
		Product actualProduct = productMapper.toDomain(productDTORequest);
		Assertions.assertEquals(productEntityRequest, actualProduct);
	}

}
