package at.wirecube.examples.products.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import at.wirecube.examples.products.dto.ProductDTO;
import at.wirecube.examples.products.service.ProductService;

@ExtendWith(MockitoExtension.class)
public class ProductControllerTest {

	@InjectMocks
	private ProductController productController;

	@Mock
	private ProductService productService;

	private ObjectMapper objectMapper;

	private ProductDTO productDTOResponse;

	private List<ProductDTO> responseProductDTOList;

	@BeforeEach
	public void setup() throws JsonParseException, JsonMappingException, IOException {
		MockitoAnnotations.openMocks(this);
		objectMapper = new ObjectMapper();

		File productDTOResponseFile = new File("src/test/resources/product-dto-response.json");
		Assertions.assertTrue(productDTOResponseFile.exists());
		productDTOResponse = objectMapper.readValue(productDTOResponseFile, ProductDTO.class);

		responseProductDTOList = new ArrayList<>();
		responseProductDTOList.add(productDTOResponse);
	}

	@Test
	public void saveProductTestSuccess() {
		Mockito.when(productService.saveProduct(Mockito.any())).thenReturn(productDTOResponse);
		ProductDTO actualResponse = productController.saveProduct(Mockito.any());
		System.out.println(actualResponse);
		Assertions.assertEquals(productDTOResponse, actualResponse);
	}

	@Test
	public void getProductListTestSuccess() {
		Mockito.when(productService.getProducts()).thenReturn(responseProductDTOList);
		List<ProductDTO> actualProductDTOResponse = productController.getProducts();
		Assertions.assertEquals(responseProductDTOList, actualProductDTOResponse);
	}

	@Test
	public void getProductTestSuccess() {
		Mockito.when(productService.getProductById(Mockito.anyLong())).thenReturn(productDTOResponse);
		ProductDTO actualProductResponse = productController.getProductById(Mockito.anyLong());
		Assertions.assertEquals(productDTOResponse, actualProductResponse);
	}

	@Test
	public void deleteProductTestSuccess() {
		productController.deleteProductById(Mockito.anyLong());
		Mockito.verify(productService, Mockito.times(1)).deleteProduct(Mockito.anyLong());
	}

	@Test
	public void updateProductTestSuccess() {
		Mockito.when(productService.updateProduct(Mockito.anyLong(), Mockito.any())).thenReturn(productDTOResponse);
		ProductDTO actualProductResponse = productController.updateProductById(Mockito.anyLong(), Mockito.any());
		Assertions.assertEquals(productDTOResponse, actualProductResponse);
	}

}
