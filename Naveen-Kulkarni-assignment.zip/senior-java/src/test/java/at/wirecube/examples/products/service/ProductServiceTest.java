package at.wirecube.examples.products.service;

import static org.mockito.Mockito.times;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import at.wirecube.examples.products.domain.Product;
import at.wirecube.examples.products.dto.ProductDTO;
import at.wirecube.examples.products.exception.ProductNotFoundException;
import at.wirecube.examples.products.mapper.ProductMapper;
import at.wirecube.examples.products.repository.ProductRepository;
import at.wirecube.examples.products.service.impl.ProductServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

	@InjectMocks
	private ProductServiceImpl productService;

	@Mock
	private ProductMapper productMapper;

	@Mock
	private ProductRepository productRepository;

	private ObjectMapper objectMapper;

	private ProductDTO productDTORequest;

	private ProductDTO productDTOResponse;

	private Product productEntityRequest;

	private Product productEntityResponse;

	private List<ProductDTO> responseProductDTOList;

	private List<Product> responseProductList;

	@BeforeEach
	public void setup() throws JsonParseException, JsonMappingException, IOException {
		MockitoAnnotations.openMocks(this);
		objectMapper = new ObjectMapper();

		File productDTORequestFile = new File("src/test/resources/product-dto-request.json");
		Assertions.assertTrue(productDTORequestFile.exists());
		productDTORequest = objectMapper.readValue(productDTORequestFile, ProductDTO.class);

		File productDTOResponseFile = new File("src/test/resources/product-dto-response.json");
		Assertions.assertTrue(productDTOResponseFile.exists());
		productDTOResponse = objectMapper.readValue(productDTOResponseFile, ProductDTO.class);

		File productEntityRequestFile = new File("src/test/resources/product-entity-request.json");
		Assertions.assertTrue(productEntityRequestFile.exists());
		productEntityRequest = objectMapper.readValue(productEntityRequestFile, Product.class);

		File productEntityResponseFile = new File("src/test/resources/product-entity-response.json");
		Assertions.assertTrue(productEntityResponseFile.exists());
		productEntityResponse = objectMapper.readValue(productEntityResponseFile, Product.class);

		responseProductDTOList = new ArrayList<>();
		responseProductDTOList.add(productDTOResponse);
		responseProductList = new ArrayList<>();
		responseProductList.add(productEntityResponse);
	}

	@Test
	public void saveProductTestSuccess() {

		Mockito.when(productMapper.toDomain(Mockito.any())).thenReturn(productEntityRequest);
		Mockito.when(productRepository.save(Mockito.any())).thenReturn(productEntityResponse);
		Mockito.when(productMapper.toDTO(Mockito.any())).thenReturn(productDTOResponse);

		ProductDTO actualProductDTOResponse = productService.saveProduct(productDTORequest);

		Assertions.assertEquals(productDTOResponse, actualProductDTOResponse);
	}

	@Test
	public void getProductByIdTestSuccess() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.of(productEntityResponse));
		Mockito.when(productMapper.toDTO(Mockito.any())).thenReturn(productDTOResponse);

		ProductDTO actualProductDTOResponse = productService.getProductById(Mockito.anyLong());

		Assertions.assertEquals(productDTOResponse, actualProductDTOResponse);
	}

	@Test
	public void getProductByIdTestException() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.empty());

		Assertions.assertThrows(ProductNotFoundException.class, () -> productService.getProductById(Mockito.anyLong()));
	}

	@Test
	public void getProductsTestSuccess() {
		Mockito.when(productRepository.findAll()).thenReturn(responseProductList);
		Mockito.when(productMapper.toDTO(Mockito.any())).thenReturn(productDTOResponse);
		List<ProductDTO> actualProductDTOList = productService.getProducts();
		Assertions.assertEquals(responseProductDTOList, actualProductDTOList);
	}

	@Test
	public void updateProductByIdTestException() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.empty());

		Assertions.assertThrows(ProductNotFoundException.class,
				() -> productService.updateProduct(1L, productDTORequest));
	}

	@Test
	public void updateProductByIdTestSuccess() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.of(productEntityResponse));
		Mockito.when(productMapper.toDomain(Mockito.any())).thenReturn(productEntityRequest);
		Mockito.when(productRepository.save(Mockito.any())).thenReturn(productEntityResponse);
		Mockito.when(productMapper.toDTO(Mockito.any())).thenReturn(productDTOResponse);
		ProductDTO actualProductDTOResponse = productService.updateProduct(1L, productDTORequest);
		Assertions.assertEquals(productDTOResponse, actualProductDTOResponse);
	}

	@Test
	public void deleteProductByIdTestException() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.empty());

		Assertions.assertThrows(ProductNotFoundException.class, () -> productService.deleteProduct(Mockito.anyLong()));
	}
	
	@Test
	public void deleteProductByIdTestSuccess() {

		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.of(productEntityResponse));
		Mockito.doNothing().when(productRepository).delete(Mockito.any());
		productService.deleteProduct(Mockito.anyLong());
		Mockito.verify(productRepository, times(1)).delete(Mockito.any());
	}
}