package at.wirecube.examples.products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
